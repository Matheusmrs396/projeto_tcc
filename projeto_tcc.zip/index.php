<?php
header("Refresh: 0; url = app/views/home.php");
?>

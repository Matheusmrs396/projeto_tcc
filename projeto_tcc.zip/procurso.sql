-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: localhost    Database: procurso
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `amistoso`
--

DROP TABLE IF EXISTS `amistoso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amistoso` (
  `data` date NOT NULL,
  `local` varchar(250) CHARACTER SET utf8 NOT NULL,
  `idamistoso` int(11) NOT NULL AUTO_INCREMENT,
  `mandante` int(11) NOT NULL,
  `visitante` int(11) NOT NULL,
  PRIMARY KEY (`idamistoso`),
  KEY `fk_amistoso_time1_idx` (`mandante`),
  KEY `fk_amistoso_time2_idx` (`visitante`),
  CONSTRAINT `fk_amistoso_time1` FOREIGN KEY (`mandante`) REFERENCES `time` (`id_time`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_amistoso_time2` FOREIGN KEY (`visitante`) REFERENCES `time` (`id_time`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amistoso`
--

LOCK TABLES `amistoso` WRITE;
/*!40000 ALTER TABLE `amistoso` DISABLE KEYS */;
/*!40000 ALTER TABLE `amistoso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacao`
--

DROP TABLE IF EXISTS `notificacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificacao` (
  `mensagem` varchar(500) CHARACTER SET utf8 NOT NULL,
  `destinatario` int(11) NOT NULL,
  `remetente` int(11) NOT NULL,
  `idnotificacao` int(11) NOT NULL AUTO_INCREMENT,
  `resposta` char(3) NOT NULL,
  `tempresp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`idnotificacao`),
  KEY `fk_notificacao_usuario1_idx` (`destinatario`),
  KEY `fk_notificacao_usuario2_idx` (`remetente`),
  CONSTRAINT `fk_notificacao_usuario1` FOREIGN KEY (`destinatario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_notificacao_usuario2` FOREIGN KEY (`remetente`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacao`
--

LOCK TABLES `notificacao` WRITE;
/*!40000 ALTER TABLE `notificacao` DISABLE KEYS */;
INSERT INTO `notificacao` VALUES ('VocÃª foi ad',0,0,1,'',NULL),('VocÃª foi ad',0,0,2,'',NULL),('VocÃª foi ad',0,0,3,'',NULL),('VocÃª foi ad',0,0,4,'',NULL);
/*!40000 ALTER TABLE `notificacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time`
--

DROP TABLE IF EXISTS `time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time` (
  `nome_time` varchar(100) CHARACTER SET utf8 NOT NULL,
  `id_time` int(11) NOT NULL AUTO_INCREMENT,
  `data_criacao` date NOT NULL,
  `cidade` varchar(100) CHARACTER SET utf8 NOT NULL,
  `sigla` varchar(3) CHARACTER SET utf8 NOT NULL,
  `senha_time` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `desc_time` varchar(300) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_time`),
  UNIQUE KEY `nome_time` (`nome_time`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time`
--

LOCK TABLES `time` WRITE;
/*!40000 ALTER TABLE `time` DISABLE KEYS */;
INSERT INTO `time` VALUES ('time',10,'2001-11-12','joinville','REC','827ccb0eea8a706c4c34a16891f84e7b','sÃ³ tapa'),('Santa BÃ¡rbara FC',11,'2002-04-21','Joinville','SFC','827ccb0eea8a706c4c34a16891f84e7b','time do vagner'),('Resenha Esporte Clube',12,'2001-11-12','Joinville','REC','827ccb0eea8a706c4c34a16891f84e7b','sÃ³ tapa');
/*!40000 ALTER TABLE `time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `sobrenome` varchar(120) DEFAULT NULL,
  `nome_usuario` varchar(80) NOT NULL,
  `email_usuario` varchar(80) NOT NULL,
  `data_nascimento` varchar(30) NOT NULL,
  `senha` varchar(120) NOT NULL,
  `time_id_time` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email_usuario` (`email_usuario`),
  KEY `fk_usuario_time1_idx` (`time_id_time`)
) ENGINE=MyISAM AUTO_INCREMENT=526 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (513,'Cardoso','Cardoso','Abc@gmail.com','2008-01-10','900150983cd24fb0d6963f7d28e17f72',12),(512,'Cardoso','Enrique','2007@gmail.com','2007-08-22','202cb962ac59075b964b07152d234b70',12),(514,'Cardoso','Mateus','Mateuscardoso3112@gmail.com','2222-12-31','202cb962ac59075b964b07152d234b70',12),(524,'quintino','matheus','matheus.henrique.quintino@gmail.com','0','827ccb0eea8a706c4c34a16891f84e7b',12),(517,'zika','matheus','beicin@gmail.com','0','81dc9bdb52d04dc20036dbd8313ed055',12),(518,'zika','nego','negolua@gay.com','0','81dc9bdb52d04dc20036dbd8313ed055',12),(519,'ribeiro','aline','ribeiro@gmail.com','0','827ccb0eea8a706c4c34a16891f84e7b',0),(520,'victor','john ','johnvictor.trabalho@gmail.com','0','25d55ad283aa400af464c76d713c07ad',0),(521,'Riegel','Ivo ','ivo@gmail.com','0','20e04899c46cd16355f0f2ca77fa83b9',0),(522,'silva','matheus','testa@gmail.copm','0','81dc9bdb52d04dc20036dbd8313ed055',0),(523,'cardoso','mateus','matcardoso@gmail.com','0','827ccb0eea8a706c4c34a16891f84e7b',0),(525,'SOSTER','cardoso31','ribeiro@gmail.comm','0','827ccb0eea8a706c4c34a16891f84e7b',0);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_has_time`
--

DROP TABLE IF EXISTS `usuario_has_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_has_time` (
  `usuario_id_usuario` int(11) NOT NULL,
  `time_id_time` int(11) NOT NULL,
  `time_usuario_id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id_usuario`,`time_id_time`,`time_usuario_id_usuario`),
  KEY `fk_usuario_has_time_time1_idx` (`time_id_time`,`time_usuario_id_usuario`),
  KEY `fk_usuario_has_time_usuario1_idx` (`usuario_id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_has_time`
--

LOCK TABLES `usuario_has_time` WRITE;
/*!40000 ALTER TABLE `usuario_has_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_has_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_has_time1`
--

DROP TABLE IF EXISTS `usuario_has_time1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_has_time1` (
  `usuario_id_usuario` int(11) NOT NULL,
  `time_id_time` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id_usuario`,`time_id_time`),
  KEY `fk_usuario_has_time1_time1_idx` (`time_id_time`),
  KEY `fk_usuario_has_time1_usuario1_idx` (`usuario_id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_has_time1`
--

LOCK TABLES `usuario_has_time1` WRITE;
/*!40000 ALTER TABLE `usuario_has_time1` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_has_time1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_has_tipousuario`
--

DROP TABLE IF EXISTS `usuario_has_tipousuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario_has_tipousuario` (
  `usuario_id_usuario` int(11) NOT NULL,
  `tipousuario_idtipousuario` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id_usuario`,`tipousuario_idtipousuario`),
  KEY `fk_usuario_has_tipousuario_tipousuario1_idx` (`tipousuario_idtipousuario`),
  KEY `fk_usuario_has_tipousuario_usuario_idx` (`usuario_id_usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_has_tipousuario`
--

LOCK TABLES `usuario_has_tipousuario` WRITE;
/*!40000 ALTER TABLE `usuario_has_tipousuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_has_tipousuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-13 15:44:46

<?php
//include ('../models/Conection.php');
//include ('../models/Usuario.php');
include ('../views/cabecalho.php');
if(isset($_GET['acao'])){
    switch ($_GET['acao']) {
        case 'logar':
            $usuario=new Usuario();
            $usuario->login($_POST['email'],$_POST['password']);
            unset($usuario);
        break;

        case 'cadastrar':
            $usuario=new Usuario();
            $usuario->cadastrar($_POST['nome'],$_POST['sobrenome'],$_POST['email'],$_POST['password'],$_POST['data_nasc']);
            var_dump($usuario);
            unset($usuario);
        break;

        case 'cadastrar_time':
            $query= new Conection();
            $query->select('select * from time where nome_time ="'.$_POST['nome_time'].'"');
            if (!empty($query->dados)) {
                header("Refresh: 0; url = ../views/cadastro_time.php?u=e");
            }else{
                $time=new Time();
                $time->cadastrar_time($_POST['nome_time'],$_POST['data_criacao'],$_POST['cidade'],$_POST['sigla_time'],$_POST['desc_time'],$_POST['adm'],$_POST['modalidade']);
                unset($time);
                unset($query);
                header("Refresh: 0; url = ../views/time.php");

            }
        break;

        case 'cadastrar_amistoso':
            $amistoso = new Amistoso();
            $amistoso->cadastrar_amistoso($_POST['local'],$_POST['data'],$_POST['mandante'],$_POST['visitante'],0,0,$_POST['horario']);
            unset($amistoso);
            header("Refresh: 0; url = ../views/meus_amistosos.php");
        break;

        case 'aceitar_amistoso':
            $amistoso = new Amistoso();
            $amistoso->aceitar_amistoso($_POST['id_amistoso']);
            unset($amistoso);
            header("Refresh: 0; url = ../views/meus_amistosos.php");
        break;

        case 'rejeitar_amistoso':
            $amistoso = new Amistoso();
            $amistoso->rejeitar_amistoso($_POST['id_amistoso']);
            unset($amistoso);
            header("Refresh: 0; url = ../views/meus_amistosos.php");
        break;

        case 'lista_jogadores':
            header("Refresh: 0; url = ../views/lista_jogadores.php");
        break;

        case 'excluir_time':
            $time = new Time();
            $time->excluir_time($_POST['id_time']);
            unset($time);
            header("Refresh: 0; url = ../views/home.php");
        break;

        case 'ir_editar_time':
            header("Refresh: 0; url = ../views/editar_time.php");
        break;

        case 'editar_time':
            $time = new Time();
            $time->editar_time($_POST['nome_time'],$_POST['data_criacao'],$_POST['cidade'],$_POST['sigla_time'],$_POST['desc_time'],$_POST['modalidade'],$_POST['id_time']);
            unset($time);
            //header("Refresh: 0; url = ../views/time.php");
        break;

        case 'logout':
            session_destroy();
            header("Refresh: 1; url = ../views/home.php");
            echo"<h3>loading, please wait <h3>";
        break;

    }
}

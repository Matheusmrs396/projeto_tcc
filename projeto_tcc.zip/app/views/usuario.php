<?php
    include ('cabecalho.php');
    $time = new Time();
    $insert = 'select * from time where adm =' . $_SESSION['logado']['id_usuario'];
    $query = new Conection();
    $query->select($insert);
?>
<div class="coluna_cad_dir"></div>
<div class="barra_sup_login"></div>
<div class=" coluna_cad">
    <div class="coluna_cad2">
        <div class="ui cards">
            <div class="card">
                <div class="content">
                    <div class="header">
                        <?php echo($_SESSION['logado']['nome']); ?>
                    </div>
                    <div class="meta">
                        <?php echo($_SESSION['logado']['sobrenome']); ?>
                    </div>
                    <div class="description">Email:
                        <?php echo($_SESSION['logado']['email']); ?>
                    </div>
                    <?php
                    if (isset($query->info[0]['nome_time'])){
                        echo "<a href='time.php' class='description'>Time: ".$query->info[0]['nome_time']."</a>";
                    }
                    ?>
                    <div class='description'>Data de Nascimento:
                        <?php echo($_SESSION['logado']['data_nasc']); ?>
                    </div>
                </div>
                <div class="extra content">
                    <div class="ui two buttons">
                        <div class="ui basic green button">Approve</div>
                        <div class="ui basic red button">Decline</div>
                    </div>
                </div>
            </div>
        </div>
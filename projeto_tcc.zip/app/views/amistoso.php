<?php
include  'cabecalho.php';
?>
<div class="coluna_amistoso">
    <form enctype="multipart/form-data" action='../controllers/controler.php?acao=cadastrar_amistoso' method="post" class=" largura ui form">
        <h3 class="ui aligned center dividing header">Cadastre seu Amistoso</h3>
        <div class="two fields">
            <div class="field">
                <?php
                    $query = new Conection();
                    $insert = 'select * from time ';
                    $query->select($insert);
                    $times1 = $query->info;
                    $times2 = $query->info;
                ?>
                <label>Mandante</label>
                <select name="mandante" class="ui dropdown">
                <?php
                    foreach ($times1 as $key => $value) {
                ?>
                        <option value="<?=$value['id_time']?>"><?=$value['nome_time']?></option>
                <?php
                }
                ?>
                </select>
            </div>
            <label>Horário</label>
            <input type="time" name="horario">
            <div class="field">
                <label>Visitante</label>
                <select name="visitante" class="ui dropdown">
                    <?php
                    foreach ($times2 as $key => $value2) {
                        ?>
                        <option value="<?=$value2['id_time']?>"><?=$value2['nome_time']?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="field">
            <label>Local</label>
            <input type="text" name="local" placeholder="Local" required>
        </div>
        <div class="field">
            <label>Data</label>
            <input type="date" name="data" required>
        </div>
        <input class="ui button yellow" type="submit" name="">
    </form>
</div>

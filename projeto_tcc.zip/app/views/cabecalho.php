<?php
include '../models/Conection.php';
include '../models/Usuario.php';
include '../models/Time.php';
include '../models/Amistoso.php';
if(!isset($_SESSION)){
    session_start();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Sem nome</title>
        <link rel="stylesheet" type="text/css" href="../semantic/semantic.min.css">
        <script
                src="https://code.jquery.com/jquery-3.1.1.min.js"
                integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
                crossorigin="anonymous"></script>
        <script src="semantic/dist/semantic.min.js"></script>
        <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../css/estilo.css">
        <nav>
            <div class="pusher cor2">
                <div class="ui container ">
                    <div class="ui large secondary pointing inverted menu ">
                        <a class="toc item">
                            <i class="sidebar icon"></i>
                        </a>
                        <a  href="home.php" class="active item black">Home</a>
                        <?php
                            if (isset($_SESSION['logado'])) {
                                $time = new Time();
                                $insert = 'select * from time where adm =' . $_SESSION['logado']['id_usuario'];
                                $query = new Conection();
                                $query->select($insert);
                                if (isset($query->info[0]['nome_time'])) {
                                    echo "<a href = 'time.php' class='item'>" . $query->info[0]['nome_time'] . "</a>";
                                    echo "<a href = 'meus_amistosos.php' class='item'>Amistosos</a>";
                                }
                                unset($query);
                            }
                            if(isset($_SESSION['logado'])){
                                echo "<a href='../views/cadastro_time.php' class='item inverted'>Cadastrar Time</a>";
                            }
                        ?>
                        <div class="right item">
                        <?php
                            if(isset($_SESSION['logado'])){
                                echo "<a href='usuario.php'><button class='ui button green inverted'>".$_SESSION['logado']['nome']."</button></a>";''
                        ?>
                        <a href="../controllers/controler.php?acao=logout" class="ui button blue inverted">Logout</a>
                        <?php
                            }else{
                        ?>
                                <a href="../views/login.php" class="ui button blue inverted">Login</a>
                                <a href="cadastro_usuario.php" class="ui button green inverted">Cadastre-se</a>
                        <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
        </nav>
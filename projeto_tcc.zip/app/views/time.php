<?php
    include ('cabecalho.php');
    $time = new Time();
    $insert = 'select * from time where adm =' . $_SESSION['logado']['id_usuario'];
    $query = new Conection();
    $query->select($insert);

    if ($query->info[0]['modalidade'] == 1) {
        $modalidade = "Futebol de Campo";
    }
    if ($query->info[0]['modalidade'] == 2) {
        $modalidade = "Futsal";
    }
    if ($query->info[0]['modalidade'] == 3) {
        $modalidade = "Futebol Society";
    }

?>
<div class="coluna_cad_dir"></div>
<div class="barra_sup_login"></div>
<div class=" coluna_cad">
    <div class="ui segment">
        <p class="ui aligned center dividing header"><?= $query->info[0]['nome_time']?></p>
        <p><?= $query->info[0]['desc_time'] ?></p>
        <p>Administrado por: <?= ($_SESSION['logado']['nome']." ".$_SESSION['logado']['sobrenome']);?></p>
        <p>Criado em: <?= $query->info[0]['data_criacao']?></p>
        <p>Sigla: <?= $query->info[0]['sigla']?></p>
        <p>Cidade: <?= $query->info[0]['cidade']?></p>
        <p>Modalidade: <?= $modalidade ?></p>
        <div class="ui three buttons">
            <form enctype="multipart/form-data"
                  action='../controllers/controler.php?acao=lista_jogadores' method="post">
                <input type="hidden" name="id_time" value="<?= $query->info[0]['id_time'] ?>">
                <input type="submit" class="ui black button" value="Jogadores">
            </form>
            <form enctype="multipart/form-data"
                  action='../controllers/controler.php?acao=excluir_time' method="post">
                <input type="hidden" name="id_time" value="<?= $query->info[0]['id_time']  ?>">
                <input type="submit" class="ui red button" value="Excluir">
            </form>
            <form enctype="multipart/form-data"
                  action='../controllers/controler.php?acao=ir_editar_time' method="post">
<!--                <input type="hidden" name="id_amistoso" value="--><?//= $value2['idamistoso'] ?><!--">-->
                <input type="submit" class="ui blue button" value="Editar">
            </form>
        </div>
    </div>
</div>







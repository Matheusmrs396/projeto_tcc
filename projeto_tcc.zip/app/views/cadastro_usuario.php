<?php
include 'cabecalho.php';
?>
<div class="coluna_cad_dir"></div>
<div class="barra_sup_login"></div>
<div class=" coluna_cad">
    <div class="coluna_cad2">
        <form enctype="multipart/form-data" action='../controllers/controler.php?acao=cadastrar' method="post" class="ui form">
            <h3 class="ui aligned center dividing header">Cadastre-se</h3>
            <div class="field">
                <label>Nome</label>
                <div class="two fields">
                    <div class="field">
                        <input type="text" name="nome" placeholder="Primeiro Nome" required>
                    </div>
                    <div class="field">
                        <input type="text" name="sobrenome" placeholder="Sobrenome" required>
                    </div>
                </div>
            </div>
            <h4 class="ui header">Email</h4>
            <div class="field">
                <?php
                    if(isset($_GET['u']) and $_GET['u'] == 'e'){
                        echo'<p class="incorreto">Email ja cadastrado</p>';
                    }
                ?>
                <div class="field">
                    <div class="ui input">
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                </div>
            </div>
            <h4 class="ui header">Data de Nascimento</h4>
            <input type="date" name="data_nasc" required>
            <h4 class="ui header">Senha</h4>
            <div class="field">
                <div class="ui input">
                    <input type="password" name="password" placeholder="Senha" required>
                </div>
            </div>
            <input class="ui button" type="submit" name="">
        </form>
    </div>
</div>

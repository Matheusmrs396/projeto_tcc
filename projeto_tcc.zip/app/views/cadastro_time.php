<?php
include 'cabecalho.php';
?>
<div class="coluna_cad_dir"></div>
<div class="barra_sup_login"></div>
<div class=" coluna_cad">
    <div class="coluna_cad2">
        <form enctype="multipart/form-data" action='../controllers/controler.php?acao=cadastrar_time' method="post" class=" largura ui form">
            <h3 class="ui aligned center dividing header">Cadastre sua Equipe</h3>
            <div class="field  ">
                <div class="two fields">
                    <div class="field">
                        <h4 class="ui header">Nome do time</h4>
                        <input type="text" name="nome_time" placeholder="Nome do Time" required>
                    </div>
                    <div class="field">
                        <h4 class="ui header">Sigla</h4>
                        <input type="text" name="sigla_time" placeholder="Sigla" required>
                    </div>
                </div>
            </div>
            <h4 class="ui header">Descrição</h4>
            <div class="field">
                <div class="field">
                    <div class="ui input">
                        <input type="text" name="desc_time" placeholder="Descrição da Equipe" required>
                    </div>
                </div>
            </div>
            <div class="field  ">
                <h4 class="ui header">Cidade</h4>
                <input type="text" name="cidade" placeholder="Cidade" required>
            </div>
            <div class="two fields">
                <div class="field">
                    <label>Data Criação</label>
                    <input type="date" name="data_criacao" required>
                </div>
                <div class="field">
                    <label>Modalidade</label>
                    <select name="modalidade">
                        <option value="1">Futebol de Campo</option>
                        <option value="2">Futsal</option>
                        <option value="3">Futebol Society</option>
                    </select>
                </div>
            </div>
            <div class="field">
                <input type="hidden" name="adm" value="<?=$_SESSION['logado']['id_usuario']?>">
            </div>
            <input class="ui button yellow" type="submit" name="">
        </form>
    </div>
</div>

<?php 
include 'cabecalho.php';
?>
<div class="coluna_login_dir"></div>
    <div class="barra_sup_login"></div>
        <div class="coluna_login">
            <div class=" middle aligned center aligned grid barra_cima_login">
                <div class="column">
                    <h2 class="ui black image header">
                        <h3 class="ui aligned center dividing header">Login</h3>
                    </h2>
                    <form method="post" action='../controllers/controler.php?acao=logar' class="ui large form">
                        <div class="ui stacked segment ">
                            <?php
                                if(isset($_GET['s'])){
                                    echo'<a class="incorreto"> Login ou Senha incorreto(s)</a>';
                                }
                            ?>
                            <div class="field">
                                <div class="ui left icon input">
                                    <i class="user icon"></i>
                                    <input type="text" name="email" placeholder="Email ">
                                </div>
                            </div>
                            <div class="field">
                                <div class="ui left icon input">
                                    <i class="lock icon"></i>
                                    <input type="password" name="password" placeholder="Senha">
                                </div>
                            </div>
                            <button class="ui primary labeled icon button" type="submit">
                                <i class="unlock alternate icon"></i>
                                 Login
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</body>
</html>

<?php

include 'cabecalho.php';
?>
<style type="text/css">
    .imagemFundo{
        background-image: url("../img/fundo.jpeg");
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover ;
        position: relative;
    }
    .center_imagem{
        /*padding-top: 350px;*/
        width: 50%;
        margin-left: 40%;
    }
    .title_home{
        padding-top: 300px;
        color: #fff;
        margin-left: 35%;
    }
    .caixa{
        background-color: #fff4e4;
        opacity: 0.5;
    }
</style>
<div class="imagemFundo">
    <div class="caixa">
        <div class="title_home">
        <h1>Bem Vindo ao Soccer Events!</h1>
    </div>
    <div class="center_imagem">
        <div class="inline">
            <div class="ui primary button">Login</div>
            <div class="ui button">Cadastre-se</div>
        </div>
    </div>
    </div>
</div>

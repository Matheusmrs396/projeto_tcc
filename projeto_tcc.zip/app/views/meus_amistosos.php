<?php
    include ('cabecalho.php');
    $time = new Conection();
    $insert_time = 'select * from time where adm ='.$_SESSION['logado']['id_usuario'];
    $time->select($insert_time);
    $amistosos = new Conection();
    $insert_amistosos = 'select * from amistoso where (mandante = "'.$time->info[0]['id_time'].'") or (visitante = "'.$time->info[0]['id_time'].'")';
    $amistosos->select($insert_amistosos);
    ?>
    <div class="meio_amistosos">
        <h3 class="ui aligned center dividing header"><?php echo("Amistosos marcados por ".$time->info[0]['nome_time'] . ":"); ?></h3>
        <br>
    </div>
    <div class="coluna_amistoso">
        <div class="ui cards">
    <?php
    if (is_array($amistosos)){
    foreach ($amistosos as $key => $value) {
        foreach ($value as $chave => $value2) {
            $mandante = new Conection();
            $visitante = new Conection();
            $insert_mandante = 'select * from time where id_time=' . $value2['mandante'];
            $insert_visitante = 'select * from time where id_time=' . $value2['visitante'];
            $mandante->select($insert_mandante);
            $visitante->select($insert_visitante);
            ?>
            <div class="card">
                <div class="content">
                    <div class="titulo_amistoso">
                        <?= $mandante->info[0]['sigla'] . " " . $value2['result_mandante'] . " X " . $value2['result_visitante'] . " " . $visitante->info[0]['sigla'] ?>
                    </div>
                    <div class="meta">
                        <?= $mandante->info[0]['nome_time'] . " X " . $visitante->info[0]['nome_time'] ?>
                    </div>
                    <div class="description">
                        Data: <?= $value2['data'] ?>
                    </div>
                    <div class="description">
                        Horário: <?= $value2['horario'] ?>
                    </div>
                    <div class="description">
                        Local: <?= $value2['local'] ?>
                    </div>
                </div>
                <div class="extra content">
                    <div class="ui two buttons">
                        <form enctype="multipart/form-data"
                              action='../controllers/controler.php?acao=aceitar_amistoso' method="post">
                            <input type="hidden" name="id_amistoso" value="<?= $value2['idamistoso'] ?>">
                            <input type="submit" class="ui green button" value="Aceitar">
                        </form>
                        <form enctype="multipart/form-data"
                              action='../controllers/controler.php?acao=rejeitar_amistoso' method="post">
                            <input type="hidden" name="id_amistoso" value="<?= $value2['idamistoso'] ?>">
                            <input type="submit" class="ui red button" value="Rejeitar">
                        </form>
                    </div>
                </div>
            </div>
            <div>

            </div>
            <?php
        }
    }
    }else{
        echo "Sem amistosos cadastrados";
    }
            ?>
        </div>
    </div>

<?php
class Amistoso{
    public $id_amistoso;
    public $local;
    public $data;
    public $id_mandante;
    public $id_visitante;
    public $result_mandante;
    public $result_visitante;
    public $horario;
    public $convidador;

    public function cadastrar_amistoso($local,$data,$id_mandante,$id_visitante,$result_mandante,$result_visitante,$convidador,$horario,$id_amistoso = null){
        $this->local = $local;
        $this->data = $data;
        $this->id_mandante = $id_mandante;
        $this->id_visitante = $id_visitante;
        $this->result_mandante = $result_mandante;
        $this->result_visitante = $result_visitante;
        $this->convidador = $convidador;
        $this->horario = $horario;
        $this->id_amistoso = $id_amistoso;

        $insert = 'insert into amistoso(local,data,mandante,visitante,result_mandante,result_visitante,convidador,status,horario) values("'.$local.'","'.$data.'","'.$id_mandante.'","'.$id_visitante.'","'.$result_mandante.'","'.$result_visitante.'","'.$convidador.'",0,"'.$horario.'")';
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }
    public function aceitar_amistoso($id_amistoso){
        $this->id_amistoso = $id_amistoso;
        $insert = 'UPDATE amistoso SET status = 1 WHERE idamistoso ='.$id_amistoso;
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }
    public function rejeitar_amistoso($id_amistoso){
        $this->id_amistoso = $id_amistoso;
        $insert = 'DELETE FROM amistoso WHERE idamistoso ='.$id_amistoso;
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }
}
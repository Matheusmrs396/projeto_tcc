<?php
class Conection{
    public $info;
    public function select($query){
        try{
            $conection = new PDO('mysql:host=localhost;dbname=procurso', 'root', '');
            $stmt = $conection->prepare($query);
            $stmt->execute();
            while($conteudo =$stmt->fetch(PDO::FETCH_ASSOC)){
                $this->info[]=$conteudo;
            }
        }catch (PDOException $e){
            echo 'ERROR: ' . $e->getMessage();
        }
    }
}

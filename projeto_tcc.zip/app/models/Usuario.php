<?php
class Usuario{
    public $nome;
    public $sobrenome;
    public $email;
    public $senha;
    public $data_nasc;
    public $tipo_usuario;
    public $id_usuario;

    public function login($email, $senha){
        $this->email = $email;
        $this->senha = $senha;
        $query = new Conection;
        $query->select('select * from usuario where email_usuario = "'.$email.'"');
        $ab = $query->info[0]['senha'];
        $senha_auxiliar = $senha;
        $senha =MD5($senha_auxiliar);
        if ($ab == $senha ){
            $_SESSION['logado']=array('id_usuario' => $query->info[0]['id_usuario'],
                'nome' => $query->info[0]['nome_usuario'],
                'sobrenome' => $query->info[0]['sobrenome'],
                'email' => $query->info[0]['email_usuario'],
                'data_nasc' => $query->info[0]['data_nascimento'],
                'senha' => $query->info[0]['senha'],
                'tipo_user'=> $query->info[0]['tipo_usuario'],
            );
            header("Refresh: 0; url = ../views/home.php");
        }else{
            header("Refresh: 0; url = ../views/oi.php");
        }
    }
    public function cadastrar($nome,$sobrenome,$email,$senha,$data_nasc){
        $this->nome = $nome;
        $this->sobrenome = $sobrenome;
        $this->senha = $senha;
        $this->email = $email;
        $this->data_nasc = $data_nasc;

        $insert = 'insert into usuario(nome_usuario,sobrenome,email_usuario,senha,data_nascimento,time_id_time) values("' . $nome . '","' . $sobrenome . '","' . $email . '",MD5("' . $senha . '"),"' . $data_nasc . '",0)';
        print_r($insert);
        $query = new Conection();
        $query->select($insert);
        print_r($query);
        unset($query);
    }
}


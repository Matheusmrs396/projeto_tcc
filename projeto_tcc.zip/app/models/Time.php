<?php
class Time{
    private $id_time;
    public $nome_time;
    public $data_criacao;
    public $cidade;
    public $sigla;
    public $desc_time;
    public $adm;
    public $modalidade;

    public function cadastrar_time($nome_time,$data_criacao,$cidade,$sigla,$desc_time,$adm,$modalidade,$id_time = null){

        $this->id_time = $id_time;
        $this->nome_time = $nome_time;
        $this->data_criacao = $data_criacao;
        $this->cidade = $cidade;
        $this->sigla = $sigla;
        $this->desc_time = $desc_time;
        $this->adm = $adm;
        $this->modalidade = $modalidade;

        $insert = 'insert into time (nome_time,data_criacao,cidade,sigla,desc_time,adm,modalidade) values("'.$nome_time.'","'.$data_criacao.'","'.$cidade.'","'.$sigla.'","'.$desc_time.'","'.$adm.'","'.$modalidade.'")';
        echo $insert;
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }
    public function excluir_time($id_time){
        $this->id_time = $id_time;
        $insert = 'DELETE FROM time WHERE id_time ='.$id_time;
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }
    public function editar_time($id_time,$nome_time,$data_criacao,$cidade,$sigla,$desc_time,$modalidade){
        $this->id_time = $id_time;
        $this->nome_time = $nome_time;
        $this->data_criacao = $data_criacao;
        $this->cidade = $cidade;
        $this->sigla = $sigla;
        $this->desc_time = $desc_time;
        $this->modalidade = $modalidade;


        $insert = 'UPDATE time SET desc_time ="'.$desc_time.'"nome_time="'.$nome_time.'",data_criacao = "'.$data_criacao.'",cidade = "'.$cidade.'", sigla = "'.$sigla.'", desc_time ="'.$desc_time.'", modalidade = "'.$modalidade.'" WHERE id_time ='.$id_time;
        echo $insert;
        $query = new Conection();
        $query->select($insert);
        unset($query);
    }

}